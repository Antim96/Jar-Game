import java.util.Random;
import java.util.Scanner;

/**
 * Created by SHIVAM on 07-09-2016.
 */

public class Admin {
    private String mItemType;
    private int mMaxCount;
    private int mAssignedCount;
    private boolean mEnded = false;
    public static int count = 0;

    Scanner sc = new Scanner(System.in);

    public int Guess( int guess){

        if(guess == getAssignedCount())
            mEnded = true;

        count++;
        return count;
    }

    public boolean getEnded(){
        return mEnded;
    }

    public String getItemType() {
        return mItemType;
    }

    public void setItemType(String itemType) {
        mItemType = itemType;
    }

    public int getMaxCount() {
        return mMaxCount;
    }

    public void setMaxCount(int maxCount) {
        mMaxCount = maxCount;
    }


    public int getAssignedCount() {
        return mAssignedCount;
    }


    public int setAssignedCount(int MaxCount) {
        Random rand = new Random();
        mAssignedCount = rand.nextInt(MaxCount) + 1;
    return getAssignedCount();
    }
  public String NearGuess(int guess){
   
    int number = (guess-mAssignedCount)*100/mAssignedCount;
    //number = (number>0)?number:-1*number;
    if((number>50&&number>0) || (number<0 && number <-50)){
      return "Too high ";
    else
      return "Close";
    
  }


}
