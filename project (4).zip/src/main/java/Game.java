import java.io.Console;
import java.util.Scanner;


public class Game{
    public static void main(String[] args) {

           int c = 0;
      int num;

        Admin mAdmin = new Admin();
        System.out.println("Administrator Settings =====>");
        Scanner sc = new Scanner(System.in);
        System.out.printf("Enter the type of Item : ");
        String item = sc.nextLine();
        mAdmin.setItemType(item);
        System.out.printf("Enter the max count of %s less than 21 : ",item);
        int size = sc.nextInt();
        mAdmin.setMaxCount(size);
        mAdmin.setAssignedCount(size);
      
      System.out.printf("Player has to guess between 1 and %d",size);

        System.out.println("Player: Game On !!!\n\n");
        do {
            System.out.printf("Guess: ");
          num = sc.nextInt();
          System.out.printf("Your guess is %s from actual answer\n",mAdmin.NearGuess(num));
           c = mAdmin.Guess(num);
          

        }while(!(mAdmin.getEnded()));
        System.out.printf("Congratulations ! You guess that there are %d %s in the jar. It took you %d Guess(es).\n", num,item , c);

    }
}
